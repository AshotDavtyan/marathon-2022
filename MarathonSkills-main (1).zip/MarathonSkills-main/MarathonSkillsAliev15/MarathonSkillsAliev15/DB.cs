﻿using MarathonSkillsAliev15;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarathonSkillsDavtyan
{
    public static class Util
    {
        private static MfrathonSkillsEntities database;
            public static MfrathonSkillsEntities db
        {
            get
            {
                if (database == null)
                    database = new MfrathonSkillsEntities();
                return database; 

            } 
        }
    }
}
